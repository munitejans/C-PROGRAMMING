#include <stdio.h>

int main() {
    int units;
    scanf("%d", &units);
    float bill = 0;
    if (units <= 200) {
        bill = units * 0.5;
    } else if (units <= 400) {
        bill = units * 0.65 + 100;
    } else if (units <= 600) {
        bill = units * 0.80 + 200;
    } else {
        bill = units * 1.25 + 425;
    }
    printf("Rs.%.0f", bill);
    return 0;
}
